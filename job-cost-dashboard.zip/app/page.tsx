import JobCostDashboard from "../job-cost-dashboard"

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <JobCostDashboard />
    </main>
  )
}

