"use client"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table"
import { Separator } from "@/components/ui/separator"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Printer, Mail, Save, X } from "lucide-react"
import Image from "next/image"

interface JobSummaryProps {
  jobName: string
  jobLocation: string
  jobDate: string
  jobNotes: string
  companyInfo: any
  sections: any[]
  materials: any[]
  trucking: any[]
  calculateSectionCost: (section: any) => number
  calculateSectionLaborCost: (section: any) => number
  calculateTotalEquipmentCost: () => number
  calculateTotalLaborCost: () => number
  calculateTotalMaterialCost: () => number
  calculateTotalTruckingCost: () => number
  calculateTotalTruckingTonnage: () => number
  calculateTotalJobCost: () => number
  open: boolean
  onClose: () => void
}

export function JobSummary({
  jobName,
  jobLocation,
  jobDate,
  jobNotes,
  companyInfo,
  sections,
  materials,
  trucking,
  calculateSectionCost,
  calculateSectionLaborCost,
  calculateTotalEquipmentCost,
  calculateTotalLaborCost,
  calculateTotalMaterialCost,
  calculateTotalTruckingCost,
  calculateTotalTruckingTonnage,
  calculateTotalJobCost,
  open,
  onClose,
}: JobSummaryProps) {
  const [emailDialogOpen, setEmailDialogOpen] = useState(false)
  const printRef = useRef<HTMLDivElement>(null)

  const handlePrint = () => {
    const content = printRef.current
    if (!content) return

    const printWindow = window.open("", "_blank")
    if (!printWindow) {
      alert("Please allow pop-ups to print the job summary")
      return
    }

    // Add print-specific styles with enhanced headers and footers
    printWindow.document.write(`
      <html>
        <head>
          <title>${jobName || "Job Summary"}</title>
          <style>
            @page {
              margin: 0.75in 0.5in;
            }
            body {
              font-family: Arial, sans-serif;
              line-height: 1.5;
              color: #333;
              max-width: 8.5in;
              margin: 0 auto;
              padding: 0;
            }
            .print-container {
              padding: 0;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              margin-bottom: 1rem;
              page-break-inside: avoid;
            }
            table, th, td {
              border: 1px solid #ddd;
            }
            th, td {
              padding: 0.25rem 0.5rem;
              text-align: left;
            }
            th {
              background-color: #f5f5f5;
            }
            .header {
              display: flex;
              justify-content: space-between;
              margin-bottom: 1rem;
              page-break-inside: avoid;
            }
            .company-info {
              font-size: 0.9rem;
            }
            .job-details {
              margin-bottom: 1rem;
              padding: 0.5rem;
              background-color: #f9f9f9;
              border-radius: 4px;
              page-break-inside: avoid;
            }
            .section {
              margin-bottom: 1rem;
              page-break-inside: avoid;
            }
            .section-title {
              font-weight: bold;
              margin-bottom: 0.5rem;
            }
            .total-row {
              font-weight: bold;
            }
            .separator {
              border-top: 1px solid #ddd;
              margin: 1rem 0;
            }
            .footer {
              margin-top: 2rem;
              font-size: 0.8rem;
              text-align: center;
              color: #666;
              position: running(footer);
            }
            @page {
              @bottom-center {
                content: element(footer);
              }
            }
            @media print {
              body {
                margin: 0;
                padding: 0;
              }
              .print-container {
                padding: 0;
              }
              .page-break {
                page-break-before: always;
              }
            }
          </style>
        </head>
        <body>
          <div class="print-container">
            ${content.innerHTML}
            <div class="footer">
              <p>Generated on ${new Date().toLocaleDateString()} by Spallina Job Cost Estimator</p>
              <p>Page <span class="pageNumber"></span> of <span class="totalPages"></span></p>
            </div>
          </div>
          <script>
            window.onload = function() { 
              // Add page numbers
              const totalPages = Math.ceil(document.body.scrollHeight / 1100); // Approximate
              const pageNumbers = document.querySelectorAll('.pageNumber');
              const totalPagesElements = document.querySelectorAll('.totalPages');
              
              pageNumbers.forEach(el => el.textContent = '1');
              totalPagesElements.forEach(el => el.textContent = totalPages.toString());
              
              window.print();
            }
          </script>
        </body>
      </html>
    `)

    printWindow.document.close()
  }

  const handleEmail = () => {
    const content = printRef.current?.innerHTML || ""
    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>${jobName || "Job Summary"}</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              line-height: 1.5;
              color: #333;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              margin-bottom: 1rem;
            }
            table, th, td {
              border: 1px solid #ddd;
            }
            th, td {
              padding: 0.25rem 0.5rem;
              text-align: left;
            }
            th {
              background-color: #f5f5f5;
            }
            .header {
              display: flex;
              justify-content: space-between;
              margin-bottom: 1rem;
            }
            .company-info {
              font-size: 0.9rem;
            }
            .job-details {
              margin-bottom: 1rem;
              padding: 0.5rem;
              background-color: #f9f9f9;
              border-radius: 4px;
            }
            .section {
              margin-bottom: 1rem;
            }
            .section-title {
              font-weight: bold;
              margin-bottom: 0.5rem;
            }
            .total-row {
              font-weight: bold;
            }
            .separator {
              border-top: 1px solid #ddd;
              margin: 1rem 0;
            }
            .footer {
              margin-top: 2rem;
              font-size: 0.8rem;
              text-align: center;
              color: #666;
            }
          </style>
        </head>
        <body>
          ${content}
          <div class="footer">
            <p>Generated on ${new Date().toLocaleDateString()} by Spallina Job Cost Estimator</p>
          </div>
        </body>
      </html>
    `

    // Create a Blob with the HTML content
    const blob = new Blob([htmlContent], { type: "text/html" })
    const url = URL.createObjectURL(blob)

    // Create a temporary link to download the file
    const tempLink = document.createElement("a")
    tempLink.href = url
    tempLink.download = `${jobName || "Job_Summary"}.html`

    // Trigger download to create the file
    document.body.appendChild(tempLink)
    tempLink.click()
    document.body.removeChild(tempLink)

    // Create mailto link with attachment instructions
    const subject = encodeURIComponent(`Job Summary: ${jobName || "Untitled Job"}`)
    const body = encodeURIComponent(
      `Please find attached the job summary for ${jobName || "the job"}.\n\nTotal Cost: $${calculateTotalJobCost().toFixed(2)}\n\nNote: The HTML file has been downloaded to your device. Please attach it to this email before sending.`,
    )

    // Open email client
    window.location.href = `mailto:?subject=${subject}&body=${body}`

    // Clean up
    URL.revokeObjectURL(url)
    setEmailDialogOpen(false)
  }

  const sendEmail = (email) => {
    handleEmail()
  }

  const handleSaveAs = () => {
    // Create a blob with the job summary content
    const content = printRef.current?.innerHTML || ""
    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>${jobName || "Job Summary"}</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              line-height: 1.5;
              color: #333;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              margin-bottom: 1rem;
            }
            table, th, td {
              border: 1px solid #ddd;
            }
            th, td {
              padding: 0.25rem 0.5rem;
              text-align: left;
            }
            th {
              background-color: #f5f5f5;
            }
            .header {
              display: flex;
              justify-content: space-between;
              margin-bottom: 1rem;
            }
            .company-info {
              font-size: 0.9rem;
            }
            .job-details {
              margin-bottom: 1rem;
              padding: 0.5rem;
              background-color: #f9f9f9;
              border-radius: 4px;
            }
            .section {
              margin-bottom: 1rem;
            }
            .section-title {
              font-weight: bold;
              margin-bottom: 0.5rem;
            }
            .total-row {
              font-weight: bold;
            }
            .separator {
              border-top: 1px solid #ddd;
              margin: 1rem 0;
            }
            .footer {
              margin-top: 2rem;
              font-size: 0.8rem;
              text-align: center;
              color: #666;
            }
          </style>
        </head>
        <body>
          ${content}
          <div class="footer">
            <p>Generated on ${new Date().toLocaleDateString()} by Spallina Job Cost Estimator</p>
          </div>
        </body>
      </html>
    `

    const blob = new Blob([htmlContent], { type: "text/html" })
    const url = URL.createObjectURL(blob)

    // Create a link and trigger a download
    const a = document.createElement("a")
    a.href = url
    a.download = `${jobName || "Job Summary"}.html`
    document.body.appendChild(a)
    a.click()

    // Clean up
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  if (!open) return null

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex justify-between items-center">
            <span>Job Summary</span>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={handlePrint}>
                <Printer className="h-4 w-4 mr-2" />
                Print
              </Button>
              <Button variant="outline" size="sm" onClick={handleEmail}>
                <Mail className="h-4 w-4 mr-2" />
                Email
              </Button>
              <Button variant="outline" size="sm" onClick={handleSaveAs}>
                <Save className="h-4 w-4 mr-2" />
                Save As
              </Button>
              <Button variant="ghost" size="sm" onClick={onClose}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </DialogTitle>
        </DialogHeader>

        <div ref={printRef} className="print-friendly p-6 bg-white">
          <div className="header flex justify-between items-start mb-6">
            <div>
              <div className="flex items-center gap-4 mb-2">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Spallina%20small.jpg-4BsMemYEpChodSFMWplR0uSO8pVrll.jpeg"
                  alt="Spallina Materials Logo"
                  width={100}
                  height={50}
                  className="object-contain"
                />
                <h1 className="text-2xl font-bold">Job Cost Estimate</h1>
              </div>
              <div className="company-info text-sm">
                <p>{companyInfo.name}</p>
                <p>{companyInfo.address}</p>
                <p>
                  {companyInfo.city}, {companyInfo.state} {companyInfo.zip}
                </p>
                <p>Phone: {companyInfo.phone}</p>
                <p>Email: {companyInfo.email}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="font-bold">Date: {jobDate || new Date().toLocaleDateString()}</p>
              <p className="text-sm">
                Estimate #: EST-
                {Math.floor(Math.random() * 10000)
                  .toString()
                  .padStart(4, "0")}
              </p>
            </div>
          </div>

          <div className="job-details bg-muted p-4 rounded-md mb-6">
            <h2 className="font-bold text-lg mb-2">Job Information</h2>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <p>
                  <span className="font-semibold">Job Name:</span> {jobName || "Untitled Job"}
                </p>
                <p>
                  <span className="font-semibold">Location:</span> {jobLocation || "N/A"}
                </p>
              </div>
              <div>
                <p>
                  <span className="font-semibold">Date:</span> {jobDate || "N/A"}
                </p>
              </div>
            </div>
            {jobNotes && (
              <div className="mt-2">
                <p className="font-semibold">Notes:</p>
                <p className="text-sm">{jobNotes}</p>
              </div>
            )}
          </div>

          {sections
            .filter((section) => section.selected)
            .map((section) => (
              <div key={section.id} className="section mb-6">
                <h2 className="font-bold text-lg mb-2">{section.name}</h2>

                <h3 className="font-semibold text-md mb-2">Equipment</h3>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Equipment</TableHead>
                      <TableHead>Hours</TableHead>
                      <TableHead>Rate</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {section.items.map((item) => (
                      <TableRow key={`eq-${item.id}`}>
                        <TableCell>{item.equipment}</TableCell>
                        <TableCell>{item.hours}</TableCell>
                        <TableCell>${item.rate}/hr</TableCell>
                        <TableCell className="text-right">${(item.hours * item.rate).toFixed(2)}</TableCell>
                      </TableRow>
                    ))}
                    <TableRow className="total-row">
                      <TableCell colSpan={3} className="text-right font-bold">
                        Equipment Subtotal:
                      </TableCell>
                      <TableCell className="text-right font-bold">
                        ${calculateSectionCost(section).toFixed(2)}
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>

                <h3 className="font-semibold text-md mb-2 mt-4">Labor</h3>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Role</TableHead>
                      <TableHead>Hours</TableHead>
                      <TableHead>Rate</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {section.labor.map((item) => (
                      <TableRow key={`labor-${item.id}`}>
                        <TableCell>{item.role}</TableCell>
                        <TableCell>{item.hours}</TableCell>
                        <TableCell>${item.rate}/hr</TableCell>
                        <TableCell className="text-right">${(item.hours * item.rate).toFixed(2)}</TableCell>
                      </TableRow>
                    ))}
                    <TableRow className="total-row">
                      <TableCell colSpan={3} className="text-right font-bold">
                        Labor Subtotal:
                      </TableCell>
                      <TableCell className="text-right font-bold">
                        ${calculateSectionLaborCost(section).toFixed(2)}
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>

                <div className="flex justify-between items-center mt-4 font-bold">
                  <span>Section Total:</span>
                  <span>${(calculateSectionCost(section) + calculateSectionLaborCost(section)).toFixed(2)}</span>
                </div>

                <Separator className="my-4" />
              </div>
            ))}

          <div className="section mb-6">
            <h2 className="font-bold text-lg mb-2">Materials</h2>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Material</TableHead>
                  <TableHead>Quantity</TableHead>
                  <TableHead>Unit</TableHead>
                  <TableHead>Price per Unit</TableHead>
                  <TableHead className="text-right">Total</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {materials.map((material) => (
                  <TableRow key={material.id}>
                    <TableCell>{material.name}</TableCell>
                    <TableCell>{material.quantity}</TableCell>
                    <TableCell>{material.unit}</TableCell>
                    <TableCell>${material.pricePerUnit}</TableCell>
                    <TableCell className="text-right">
                      ${(material.quantity * material.pricePerUnit).toFixed(2)}
                    </TableCell>
                  </TableRow>
                ))}
                <TableRow className="total-row">
                  <TableCell colSpan={4} className="text-right font-bold">
                    Materials Subtotal:
                  </TableCell>
                  <TableCell className="text-right font-bold">${calculateTotalMaterialCost().toFixed(2)}</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>

          <div className="section mb-6">
            <h2 className="font-bold text-lg mb-2">Trucking</h2>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Truck Type</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Tonnage per Truck</TableHead>
                  <TableHead>Cost per Truck</TableHead>
                  <TableHead>Total Tonnage</TableHead>
                  <TableHead className="text-right">Total Cost</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {trucking.map((truck) => (
                  <TableRow key={truck.id}>
                    <TableCell>{truck.type}</TableCell>
                    <TableCell>{truck.amount}</TableCell>
                    <TableCell>{truck.tonnage} tons</TableCell>
                    <TableCell>${truck.costPerTruck}</TableCell>
                    <TableCell>{truck.totalTonnage} tons</TableCell>
                    <TableCell className="text-right">${truck.totalCost.toFixed(2)}</TableCell>
                  </TableRow>
                ))}
                <TableRow className="total-row">
                  <TableCell colSpan={4} className="text-right font-bold">
                    Total Tonnage:
                  </TableCell>
                  <TableCell className="font-bold">{calculateTotalTruckingTonnage().toFixed(2)} tons</TableCell>
                  <TableCell className="text-right"></TableCell>
                </TableRow>
                <TableRow className="total-row">
                  <TableCell colSpan={5} className="text-right font-bold">
                    Trucking Subtotal:
                  </TableCell>
                  <TableCell className="text-right font-bold">${calculateTotalTruckingCost().toFixed(2)}</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>

          <Separator className="my-6" />

          <div className="total-summary">
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="font-semibold">Equipment Total:</span>
                  <span>${calculateTotalEquipmentCost().toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-semibold">Labor Total:</span>
                  <span>${calculateTotalLaborCost().toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-semibold">Materials Total:</span>
                  <span>${calculateTotalMaterialCost().toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="font-semibold">Trucking Total:</span>
                  <span>${calculateTotalTruckingCost().toFixed(2)}</span>
                </div>
              </div>
            </div>

            <div className="flex justify-between items-center text-lg font-bold mb-2 p-2 bg-muted rounded">
              <span>Total Job Cost:</span>
              <span>${calculateTotalJobCost().toFixed(2)}</span>
            </div>
            <p className="text-sm text-muted-foreground">
              This estimate is valid for 30 days from the date of issue. Please contact us with any questions.
            </p>
          </div>
        </div>
      </DialogContent>

      {/* Email Dialog */}
      <Dialog open={emailDialogOpen} onOpenChange={setEmailDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Email Job Summary</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label htmlFor="email" className="text-sm font-medium">
                Email Address
              </label>
              <input
                id="email"
                type="email"
                className="w-full p-2 border rounded-md"
                placeholder="Enter recipient email"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={() => setEmailDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={() => sendEmail((document.getElementById("email") as HTMLInputElement).value)}>
              Send Email
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </Dialog>
  )
}

