"use client"

import { useState, useEffect } from "react"
import { Plus, Trash2, Settings, ChevronDown, ChevronUp, Printer, Mail } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableHeader, TableRow, TableHead, TableBody, TableCell } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import Image from "next/image"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { JobSummary } from "./job-summary"

export default function JobCostDashboard() {
  const [jobName, setJobName] = useState("")
  const [jobLocation, setJobLocation] = useState("")
  const [jobDate, setJobDate] = useState("")
  const [jobNotes, setJobNotes] = useState("")
  const [configDialogOpen, setConfigDialogOpen] = useState(false)
  const [jobSummaryOpen, setJobSummaryOpen] = useState(false)
  const [companyInfo, setCompanyInfo] = useState({
    name: "Spallina Materials",
    address: "123 Paving Way",
    city: "Asphalt City",
    state: "NY",
    zip: "12345",
    phone: "(555) 123-4567",
    email: "info@spallinamaterials.com",
  })
  const [showItemizedSummary, setShowItemizedSummary] = useState(true)

  const [sections, setSections] = useState([
    {
      id: 1,
      name: "1️⃣ Prep",
      selected: false,
      items: [
        { id: 1, equipment: "Excavator", hours: 4, rate: 100 },
        { id: 2, equipment: "Skid Steer", hours: 6, rate: 75 },
      ],
      labor: [
        { id: 1, role: "Foreman", hours: 10, rate: 45 },
        { id: 2, role: "Operator", hours: 8, rate: 35 },
        { id: 3, role: "Laborer", hours: 12, rate: 25 },
      ],
    },
    {
      id: 2,
      name: "2️⃣ Bulk Milling",
      selected: false,
      items: [
        { id: 1, equipment: "Milling Machine", hours: 8, rate: 200 },
        { id: 2, equipment: "Dump Truck", hours: 10, rate: 85 },
      ],
      labor: [
        { id: 1, role: "Foreman", hours: 10, rate: 45 },
        { id: 2, role: "Operator", hours: 8, rate: 35 },
        { id: 3, role: "Laborer", hours: 12, rate: 25 },
      ],
    },
    {
      id: 3,
      name: "3️⃣ Clean Up Milling",
      selected: false,
      items: [
        { id: 1, equipment: "Milling Machine", hours: 4, rate: 200 },
        { id: 2, equipment: "Sweeper", hours: 3, rate: 95 },
      ],
      labor: [
        { id: 1, role: "Foreman", hours: 10, rate: 45 },
        { id: 2, role: "Operator", hours: 8, rate: 35 },
        { id: 3, role: "Laborer", hours: 12, rate: 25 },
      ],
    },
    {
      id: 4,
      name: "4️⃣ Rebate Milling",
      selected: false,
      items: [
        { id: 1, equipment: "Milling Machine", hours: 6, rate: 200 },
        { id: 2, equipment: "Dump Truck", hours: 6, rate: 85 },
      ],
      labor: [
        { id: 1, role: "Foreman", hours: 10, rate: 45 },
        { id: 2, role: "Operator", hours: 8, rate: 35 },
        { id: 3, role: "Laborer", hours: 12, rate: 25 },
      ],
    },
    {
      id: 5,
      name: "5️⃣ Mainline Paving",
      selected: false,
      items: [
        { id: 1, equipment: "Paver", hours: 6, rate: 150 },
        { id: 2, equipment: "Roller", hours: 8, rate: 120 },
        { id: 3, equipment: "Material Truck", hours: 10, rate: 90 },
      ],
      labor: [
        { id: 1, role: "Foreman", hours: 10, rate: 45 },
        { id: 2, role: "Operator", hours: 8, rate: 35 },
        { id: 3, role: "Laborer", hours: 12, rate: 25 },
      ],
    },
    {
      id: 6,
      name: "6️⃣ Intersection Paving",
      selected: false,
      items: [
        { id: 1, equipment: "Paver", hours: 4, rate: 150 },
        { id: 2, equipment: "Roller", hours: 5, rate: 120 },
        { id: 3, equipment: "Material Truck", hours: 6, rate: 90 },
      ],
      labor: [
        { id: 1, role: "Foreman", hours: 10, rate: 45 },
        { id: 2, role: "Operator", hours: 8, rate: 35 },
        { id: 3, role: "Laborer", hours: 12, rate: 25 },
      ],
    },
    {
      id: 7,
      name: "7️⃣ Driveway Paving",
      selected: false,
      items: [
        { id: 1, equipment: "Skid Steer", hours: 4, rate: 75 },
        { id: 2, equipment: "Roller", hours: 3, rate: 120 },
      ],
      labor: [
        { id: 1, role: "Foreman", hours: 10, rate: 45 },
        { id: 2, role: "Operator", hours: 8, rate: 35 },
        { id: 3, role: "Laborer", hours: 12, rate: 25 },
      ],
    },
    {
      id: 8,
      name: "8️⃣ Centerline Joint Seal",
      selected: false,
      items: [
        { id: 1, equipment: "Joint Sealer", hours: 5, rate: 110 },
        { id: 2, equipment: "Pickup Truck", hours: 5, rate: 45 },
      ],
      labor: [
        { id: 1, role: "Foreman", hours: 10, rate: 45 },
        { id: 2, role: "Operator", hours: 8, rate: 35 },
        { id: 3, role: "Laborer", hours: 12, rate: 25 },
      ],
    },
    {
      id: 9,
      name: "9️⃣ Pavement Markings",
      selected: false,
      items: [
        { id: 1, equipment: "Striping Machine", hours: 6, rate: 95 },
        { id: 2, equipment: "Pickup Truck", hours: 6, rate: 45 },
      ],
      labor: [
        { id: 1, role: "Foreman", hours: 10, rate: 45 },
        { id: 2, role: "Operator", hours: 8, rate: 35 },
        { id: 3, role: "Laborer", hours: 12, rate: 25 },
      ],
    },
    {
      id: 10,
      name: "🔟 Bonds",
      selected: false,
      items: [{ id: 1, equipment: "Administrative Fee", hours: 1, rate: 500 }],
      labor: [
        { id: 1, role: "Foreman", hours: 0, rate: 45 },
        { id: 2, role: "Administrator", hours: 2, rate: 35 },
        { id: 3, role: "Laborer", hours: 0, rate: 25 },
      ],
    },
  ])

  const [materials, setMaterials] = useState([
    { id: 1, name: "Asphalt", quantity: 100, unit: "tons", pricePerUnit: 85 },
    { id: 2, name: "Aggregate Base", quantity: 50, unit: "tons", pricePerUnit: 45 },
    { id: 3, name: "Tack Coat", quantity: 25, unit: "gallons", pricePerUnit: 12 },
  ])

  const [trucking, setTrucking] = useState([
    { id: 1, type: "Tractor Trailer", amount: 2, tonnage: 24, costPerTruck: 125, totalCost: 250, totalTonnage: 48 },
    { id: 2, type: "Triaxle", amount: 3, tonnage: 16, costPerTruck: 95, totalCost: 285, totalTonnage: 48 },
    { id: 3, type: "Dump Truck", amount: 2, tonnage: 12, costPerTruck: 85, totalCost: 170, totalTonnage: 24 },
  ])

  const [equipmentRates, setEquipmentRates] = useState({
    Excavator: 100,
    "Skid Steer": 75,
    "Milling Machine": 200,
    "Dump Truck": 85,
    Sweeper: 95,
    Paver: 150,
    Roller: 120,
    "Material Truck": 90,
    "Joint Sealer": 110,
    "Striping Machine": 95,
    "Pickup Truck": 45,
    "Administrative Fee": 500,
  })

  const [truckingRates, setTruckingRates] = useState({
    "Tractor Trailer": { tonnage: 24, costPerTruck: 125 },
    Triaxle: { tonnage: 16, costPerTruck: 95 },
    "Dump Truck": { tonnage: 12, costPerTruck: 85 },
  })

  useEffect(() => {
    // Load data from localStorage when component mounts
    const loadSavedData = () => {
      try {
        const savedJobName = localStorage.getItem("jobName")
        const savedJobLocation = localStorage.getItem("jobLocation")
        const savedJobDate = localStorage.getItem("jobDate")
        const savedJobNotes = localStorage.getItem("jobNotes")
        const savedSections = localStorage.getItem("sections")
        const savedMaterials = localStorage.getItem("materials")
        const savedTrucking = localStorage.getItem("trucking")
        const savedEquipmentRates = localStorage.getItem("equipmentRates")
        const savedTruckingRates = localStorage.getItem("truckingRates")
        const savedCompanyInfo = localStorage.getItem("companyInfo")
        const savedShowItemizedSummary = localStorage.getItem("showItemizedSummary")

        if (savedJobName) setJobName(savedJobName)
        if (savedJobLocation) setJobLocation(savedJobLocation)
        if (savedJobDate) setJobDate(savedJobDate)
        if (savedJobNotes) setJobNotes(savedJobNotes)
        if (savedSections) setSections(JSON.parse(savedSections))
        if (savedMaterials) setMaterials(JSON.parse(savedMaterials))
        if (savedTrucking) setTrucking(JSON.parse(savedTrucking))
        if (savedEquipmentRates) setEquipmentRates(JSON.parse(savedEquipmentRates))
        if (savedTruckingRates) setTruckingRates(JSON.parse(savedTruckingRates))
        if (savedCompanyInfo) setCompanyInfo(JSON.parse(savedCompanyInfo))
        if (savedShowItemizedSummary) setShowItemizedSummary(JSON.parse(savedShowItemizedSummary))
      } catch (error) {
        console.error("Error loading saved data:", error)
      }
    }

    loadSavedData()
  }, [])

  const saveToLocalStorage = () => {
    try {
      localStorage.setItem("jobName", jobName)
      localStorage.setItem("jobLocation", jobLocation)
      localStorage.setItem("jobDate", jobDate)
      localStorage.setItem("jobNotes", jobNotes)
      localStorage.setItem("sections", JSON.stringify(sections))
      localStorage.setItem("materials", JSON.stringify(materials))
      localStorage.setItem("trucking", JSON.stringify(trucking))
      localStorage.setItem("equipmentRates", JSON.stringify(equipmentRates))
      localStorage.setItem("truckingRates", JSON.stringify(truckingRates))
      localStorage.setItem("companyInfo", JSON.stringify(companyInfo))
      localStorage.setItem("showItemizedSummary", JSON.stringify(showItemizedSummary))
    } catch (error) {
      console.error("Error saving data:", error)
    }
  }

  // Save section configurations without job details
  const saveSectionConfigurations = () => {
    try {
      // Create a deep copy of the sections but clear the 'selected' flag
      const sectionConfigs = JSON.parse(JSON.stringify(sections)).map((section) => ({
        ...section,
        selected: false, // Reset selection for new jobs
      }))
      localStorage.setItem("sectionConfigurations", JSON.stringify(sectionConfigs))
      alert("Section configurations saved for future jobs!")
    } catch (error) {
      console.error("Error saving section configurations:", error)
    }
  }

  // Load section configurations but maintain current selections
  const loadSectionConfigurations = () => {
    try {
      const savedSectionConfigs = localStorage.getItem("sectionConfigurations")
      if (savedSectionConfigs) {
        const parsedConfigs = JSON.parse(savedSectionConfigs)
        // Preserve current selections
        const updatedSections = parsedConfigs.map((savedSection, index) => {
          const currentSection = sections[index] || {}
          return {
            ...savedSection,
            selected: currentSection.selected || false,
          }
        })
        setSections(updatedSections)
        saveToLocalStorage()
      }
    } catch (error) {
      console.error("Error loading section configurations:", error)
    }
  }

  const toggleSection = (id) => {
    const updatedSections = sections.map((section) =>
      section.id === id ? { ...section, selected: !section.selected } : section,
    )
    setSections(updatedSections)
    // Save to localStorage after state update
    setTimeout(() => saveToLocalStorage(), 0)
  }

  const addEquipmentItem = (sectionId) => {
    setSections(
      sections.map((section) => {
        if (section.id === sectionId) {
          const newId = section.items.length > 0 ? Math.max(...section.items.map((item) => item.id)) + 1 : 1
          return {
            ...section,
            items: [
              ...section.items,
              {
                id: newId,
                equipment: Object.keys(equipmentRates)[0],
                hours: 0,
                rate: Object.values(equipmentRates)[0],
              },
            ],
          }
        }
        return section
      }),
    )
    setTimeout(() => saveToLocalStorage(), 0)
  }

  const removeEquipmentItem = (sectionId, itemId) => {
    setSections(
      sections.map((section) => {
        if (section.id === sectionId) {
          return {
            ...section,
            items: section.items.filter((item) => item.id !== itemId),
          }
        }
        return section
      }),
    )
    setTimeout(() => saveToLocalStorage(), 0)
  }

  const updateEquipmentItem = (sectionId, itemId, field, value) => {
    const updatedSections = sections.map((section) => {
      if (section.id === sectionId) {
        return {
          ...section,
          items: section.items.map((item) => {
            if (item.id === itemId) {
              if (field === "equipment") {
                return { ...item, [field]: value, rate: equipmentRates[value] }
              }
              return { ...item, [field]: value }
            }
            return item
          }),
        }
      }
      return section
    })
    setSections(updatedSections)
    setTimeout(() => saveToLocalStorage(), 0)
  }

  const addLaborItem = (sectionId) => {
    setSections(
      sections.map((section) => {
        if (section.id === sectionId) {
          const newId = section.labor.length > 0 ? Math.max(...section.labor.map((item) => item.id)) + 1 : 1
          return {
            ...section,
            labor: [
              ...section.labor,
              {
                id: newId,
                role: "Laborer",
                hours: 0,
                rate: 25,
              },
            ],
          }
        }
        return section
      }),
    )
    setTimeout(() => saveToLocalStorage(), 0)
  }

  const removeLaborItem = (sectionId, itemId) => {
    setSections(
      sections.map((section) => {
        if (section.id === sectionId) {
          return {
            ...section,
            labor: section.labor.filter((item) => item.id !== itemId),
          }
        }
        return section
      }),
    )
    setTimeout(() => saveToLocalStorage(), 0)
  }

  const updateLaborItem = (sectionId, itemId, field, value) => {
    const updatedSections = sections.map((section) => {
      if (section.id === sectionId) {
        return {
          ...section,
          labor: section.labor.map((item) => {
            if (item.id === itemId) {
              return { ...item, [field]: value }
            }
            return item
          }),
        }
      }
      return section
    })
    setSections(updatedSections)
    setTimeout(() => saveToLocalStorage(), 0)
  }

  const addMaterial = () => {
    const newId = materials.length > 0 ? Math.max(...materials.map((item) => item.id)) + 1 : 1
    setMaterials([...materials, { id: newId, name: "", quantity: 0, unit: "tons", pricePerUnit: 0 }])
    setTimeout(() => saveToLocalStorage(), 0)
  }

  const removeMaterial = (id) => {
    setMaterials(materials.filter((material) => material.id !== id))
    setTimeout(() => saveToLocalStorage(), 0)
  }

  const updateMaterial = (id, field, value) => {
    setMaterials(
      materials.map((material) => {
        if (material.id === id) {
          return { ...material, [field]: value }
        }
        return material
      }),
    )
    setTimeout(() => saveToLocalStorage(), 0)
  }

  const addTrucking = () => {
    const newId = trucking.length > 0 ? Math.max(...trucking.map((item) => item.id)) + 1 : 1
    const defaultType = Object.keys(truckingRates)[0]
    const defaultTonnage = truckingRates[defaultType].tonnage
    const defaultCostPerTruck = truckingRates[defaultType].costPerTruck

    setTrucking([
      ...trucking,
      {
        id: newId,
        type: defaultType,
        amount: 1,
        tonnage: defaultTonnage,
        costPerTruck: defaultCostPerTruck,
        totalCost: defaultCostPerTruck,
        totalTonnage: defaultTonnage,
      },
    ])
    setTimeout(() => saveToLocalStorage(), 0)
  }

  const removeTrucking = (id) => {
    setTrucking(trucking.filter((truck) => truck.id !== id))
    setTimeout(() => saveToLocalStorage(), 0)
  }

  const updateTrucking = (id, field, value) => {
    setTrucking(
      trucking.map((truck) => {
        if (truck.id === id) {
          // If changing truck type, update tonnage and cost per truck
          if (field === "type" && truckingRates[value]) {
            const newTonnage = truckingRates[value].tonnage
            const newCostPerTruck = truckingRates[value].costPerTruck
            const amount = truck.amount

            return {
              ...truck,
              type: value,
              tonnage: newTonnage,
              costPerTruck: newCostPerTruck,
              totalCost: amount * newCostPerTruck,
              totalTonnage: amount * newTonnage,
            }
          }

          // If changing amount, recalculate totals
          if (field === "amount") {
            const numValue = Number(value) || 0
            return {
              ...truck,
              amount: numValue,
              totalCost: numValue * truck.costPerTruck,
              totalTonnage: numValue * truck.tonnage,
            }
          }

          // For tonnage or costPerTruck, update calculated fields
          if (field === "tonnage") {
            const numValue = Number(value) || 0
            return {
              ...truck,
              tonnage: numValue,
              totalTonnage: truck.amount * numValue,
            }
          }

          if (field === "costPerTruck") {
            const numValue = Number(value) || 0
            return {
              ...truck,
              costPerTruck: numValue,
              totalCost: truck.amount * numValue,
            }
          }

          return { ...truck, [field]: value }
        }
        return truck
      }),
    )
    setTimeout(() => saveToLocalStorage(), 0)
  }

  const updateEquipmentRate = (equipment, rate) => {
    const newRate = Number.parseFloat(rate) || 0
    setEquipmentRates({
      ...equipmentRates,
      [equipment]: newRate,
    })

    // Update all items using this equipment
    setSections(
      sections.map((section) => ({
        ...section,
        items: section.items.map((item) => (item.equipment === equipment ? { ...item, rate: newRate } : item)),
      })),
    )
    setTimeout(() => saveToLocalStorage(), 0)
  }

  const updateTruckingRate = (type, field, value) => {
    const numValue = Number(value) || 0

    setTruckingRates((prev) => {
      const updatedRates = {
        ...prev,
        [type]: {
          ...prev[type],
          [field]: numValue,
        },
      }

      // Update all trucking items using this type
      setTrucking(
        trucking.map((truck) => {
          if (truck.type === type) {
            if (field === "tonnage") {
              return {
                ...truck,
                tonnage: numValue,
                totalTonnage: truck.amount * numValue,
              }
            }
            if (field === "costPerTruck") {
              return {
                ...truck,
                costPerTruck: numValue,
                totalCost: truck.amount * numValue,
              }
            }
          }
          return truck
        }),
      )

      setTimeout(() => saveToLocalStorage(), 0)
      return updatedRates
    })
  }

  const addEquipmentType = (name, rate) => {
    if (name && !equipmentRates[name]) {
      setEquipmentRates({
        ...equipmentRates,
        [name]: Number.parseFloat(rate) || 0,
      })
      setTimeout(() => saveToLocalStorage(), 0)
    }
  }

  const removeEquipmentType = (name) => {
    if (Object.keys(equipmentRates).length > 1) {
      const newRates = { ...equipmentRates }
      delete newRates[name]
      setEquipmentRates(newRates)
      setTimeout(() => saveToLocalStorage(), 0)
    }
  }

  const addTruckingType = (type, tonnage, costPerTruck) => {
    if (type && !truckingRates[type]) {
      setTruckingRates({
        ...truckingRates,
        [type]: {
          tonnage: Number(tonnage) || 0,
          costPerTruck: Number(costPerTruck) || 0,
        },
      })
      setTimeout(() => saveToLocalStorage(), 0)
    }
  }

  const removeTruckingType = (type) => {
    if (Object.keys(truckingRates).length > 1) {
      const newRates = { ...truckingRates }
      delete newRates[type]
      setTruckingRates(newRates)

      // Remove this truck type from existing trucking entries
      const remainingTypes = Object.keys(newRates)
      setTrucking(
        trucking.map((truck) => {
          if (truck.type === type) {
            const newType = remainingTypes[0]
            return {
              ...truck,
              type: newType,
              tonnage: newRates[newType].tonnage,
              costPerTruck: newRates[newType].costPerTruck,
              totalCost: truck.amount * newRates[newType].costPerTruck,
              totalTonnage: truck.amount * newRates[newType].tonnage,
            }
          }
          return truck
        }),
      )

      setTimeout(() => saveToLocalStorage(), 0)
    }
  }

  const calculateSectionCost = (section) => {
    return section.items.reduce((total, item) => total + item.hours * item.rate, 0)
  }

  const calculateSectionLaborCost = (section) => {
    return section.labor.reduce((total, item) => total + item.hours * item.rate, 0)
  }

  const calculateTotalEquipmentCost = () => {
    return sections
      .filter((section) => section.selected)
      .reduce((total, section) => total + calculateSectionCost(section), 0)
  }

  const calculateTotalLaborCost = () => {
    return sections
      .filter((section) => section.selected)
      .reduce((total, section) => total + calculateSectionLaborCost(section), 0)
  }

  const calculateTotalMaterialCost = () => {
    return materials.reduce((total, material) => total + material.quantity * material.pricePerUnit, 0)
  }

  const calculateTotalTruckingCost = () => {
    return trucking.reduce((total, truck) => total + truck.totalCost, 0)
  }

  const calculateTotalTruckingTonnage = () => {
    return trucking.reduce((total, truck) => total + truck.totalTonnage, 0)
  }

  const calculateTotalJobCost = () => {
    return (
      calculateTotalEquipmentCost() +
      calculateTotalLaborCost() +
      calculateTotalMaterialCost() +
      calculateTotalTruckingCost()
    )
  }

  const updateCompanyInfo = (field, value) => {
    const updatedCompanyInfo = {
      ...companyInfo,
      [field]: value,
    }
    setCompanyInfo(updatedCompanyInfo)
    setTimeout(() => saveToLocalStorage(), 0)
  }

  const clearJobDetails = () => {
    // Clear job-specific fields but keep configuration
    setJobName("")
    setJobLocation("")
    setJobDate("")
    setJobNotes("")

    // Reset section selections but keep configuration
    setSections(
      sections.map((section) => ({
        ...section,
        selected: false,
      })),
    )

    // Save to localStorage
    setTimeout(() => saveToLocalStorage(), 0)
  }

  return (
    <div className="container mx-auto p-4 space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-4">
          <Image
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Spallina%20small.jpg-4BsMemYEpChodSFMWplR0uSO8pVrll.jpeg"
            alt="Spallina Materials Logo"
            width={100}
            height={50}
            className="object-contain"
          />
          <h1 className="text-3xl font-bold">Spallina Job Cost Estimator</h1>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setJobSummaryOpen(true)} className="flex items-center gap-2">
            <Printer className="h-4 w-4 mr-2" />
            Print
          </Button>
          <Button variant="outline" onClick={() => setJobSummaryOpen(true)} className="flex items-center gap-2">
            <Mail className="h-4 w-4 mr-2" />
            Email
          </Button>
          <Button variant="outline" onClick={() => setConfigDialogOpen(true)} className="flex items-center gap-2">
            <Settings className="h-4 w-4" />
            Config
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Job Details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="jobName">Job Name</Label>
              <Input
                id="jobName"
                value={jobName}
                onChange={(e) => setJobName(e.target.value)}
                placeholder="Enter job name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="jobLocation">Location</Label>
              <Input
                id="jobLocation"
                value={jobLocation}
                onChange={(e) => setJobLocation(e.target.value)}
                placeholder="Enter job location"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="jobDate">Date</Label>
              <Input id="jobDate" type="date" value={jobDate} onChange={(e) => setJobDate(e.target.value)} />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="mb-4">
        <CardHeader className="pb-2">
          <CardTitle>Quick Section Selection</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setSections(sections.map((section) => ({ ...section, selected: true })))
                saveToLocalStorage()
              }}
            >
              Select All
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setSections(sections.map((section) => ({ ...section, selected: false })))
                saveToLocalStorage()
              }}
            >
              Deselect All
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setSections(
                  sections.map((section) =>
                    section.id <= 5 ? { ...section, selected: true } : { ...section, selected: false },
                  ),
                )
                saveToLocalStorage()
              }}
            >
              Milling Only
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                setSections(
                  sections.map((section) =>
                    section.id >= 5 && section.id <= 7
                      ? { ...section, selected: true }
                      : { ...section, selected: false },
                  ),
                )
                saveToLocalStorage()
              }}
            >
              Paving Only
            </Button>
            <Button variant="outline" size="sm" onClick={saveSectionConfigurations}>
              Save Config
            </Button>
            <Button variant="outline" size="sm" onClick={loadSectionConfigurations}>
              Load Config
            </Button>
            <Button variant="outline" size="sm" onClick={clearJobDetails}>
              New Job
            </Button>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="sections">
        <TabsList className="grid grid-cols-2 mb-4">
          <TabsTrigger value="sections">Job Sections</TabsTrigger>
          <TabsTrigger value="materials">Materials & Trucking</TabsTrigger>
        </TabsList>

        <TabsContent value="sections" className="space-y-4">
          <div className="grid grid-cols-1 gap-4">
            {sections.map((section) => (
              <Card key={section.id} className={section.selected ? "border-primary" : ""}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-lg">{section.name}</CardTitle>
                    <Button
                      variant={section.selected ? "default" : "outline"}
                      onClick={() => toggleSection(section.id)}
                    >
                      {section.selected ? "Selected" : "Select"}
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="pb-2">
                  {section.selected && (
                    <div className="space-y-4">
                      <div>
                        <h3 className="font-semibold mb-2">Equipment</h3>
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Equipment</TableHead>
                              <TableHead>Hours</TableHead>
                              <TableHead>Rate</TableHead>
                              <TableHead>Total</TableHead>
                              <TableHead></TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {section.items.map((item) => (
                              <TableRow key={item.id}>
                                <TableCell>
                                  <Select
                                    value={item.equipment}
                                    onValueChange={(value) =>
                                      updateEquipmentItem(section.id, item.id, "equipment", value)
                                    }
                                  >
                                    <SelectTrigger>
                                      <SelectValue placeholder="Select equipment" />
                                    </SelectTrigger>
                                    <SelectContent>
                                      {Object.keys(equipmentRates).map((equipment) => (
                                        <SelectItem key={equipment} value={equipment}>
                                          {equipment}
                                        </SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                </TableCell>
                                <TableCell>
                                  <Input
                                    type="number"
                                    value={item.hours}
                                    onChange={(e) =>
                                      updateEquipmentItem(
                                        section.id,
                                        item.id,
                                        "hours",
                                        Number.parseFloat(e.target.value) || 0,
                                      )
                                    }
                                    className="w-20"
                                  />
                                </TableCell>
                                <TableCell>${item.rate}/hr</TableCell>
                                <TableCell>${(item.hours * item.rate).toFixed(2)}</TableCell>
                                <TableCell>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => removeEquipmentItem(section.id, item.id)}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full mt-2"
                          onClick={() => addEquipmentItem(section.id)}
                        >
                          <Plus className="h-4 w-4 mr-2" /> Add Equipment
                        </Button>
                      </div>

                      <div>
                        <h3 className="font-semibold mb-2">Labor</h3>
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Role</TableHead>
                              <TableHead>Hours</TableHead>
                              <TableHead>Rate</TableHead>
                              <TableHead>Total</TableHead>
                              <TableHead></TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {section.labor.map((item) => (
                              <TableRow key={item.id}>
                                <TableCell>
                                  <Input
                                    value={item.role}
                                    onChange={(e) => updateLaborItem(section.id, item.id, "role", e.target.value)}
                                    placeholder="Role title"
                                  />
                                </TableCell>
                                <TableCell>
                                  <Input
                                    type="number"
                                    value={item.hours}
                                    onChange={(e) =>
                                      updateLaborItem(
                                        section.id,
                                        item.id,
                                        "hours",
                                        Number.parseFloat(e.target.value) || 0,
                                      )
                                    }
                                    className="w-20"
                                  />
                                </TableCell>
                                <TableCell>
                                  <div className="flex items-center">
                                    <span className="mr-1">$</span>
                                    <Input
                                      type="number"
                                      value={item.rate}
                                      onChange={(e) =>
                                        updateLaborItem(
                                          section.id,
                                          item.id,
                                          "rate",
                                          Number.parseFloat(e.target.value) || 0,
                                        )
                                      }
                                      className="w-20"
                                    />
                                  </div>
                                </TableCell>
                                <TableCell>${(item.hours * item.rate).toFixed(2)}</TableCell>
                                <TableCell>
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => removeLaborItem(section.id, item.id)}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full mt-2"
                          onClick={() => addLaborItem(section.id)}
                        >
                          <Plus className="h-4 w-4 mr-2" /> Add Labor
                        </Button>
                      </div>
                    </div>
                  )}
                  {!section.selected && (
                    <div className="text-sm text-muted-foreground">Select this section to add equipment and costs.</div>
                  )}
                </CardContent>
                <CardFooter>
                  <div className="w-full flex justify-between items-center">
                    <span className="text-sm font-medium">Section Total:</span>
                    <Badge variant="outline" className="text-base">
                      ${(calculateSectionCost(section) + calculateSectionLaborCost(section)).toFixed(2)}
                    </Badge>
                  </div>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="materials" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Materials Cost</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Material</TableHead>
                    <TableHead>Quantity</TableHead>
                    <TableHead>Unit</TableHead>
                    <TableHead>Price per Unit</TableHead>
                    <TableHead>Total</TableHead>
                    <TableHead></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {materials.map((material) => (
                    <TableRow key={material.id}>
                      <TableCell>
                        <Input
                          value={material.name}
                          onChange={(e) => updateMaterial(material.id, "name", e.target.value)}
                          placeholder="Material name"
                        />
                      </TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={material.quantity}
                          onChange={(e) =>
                            updateMaterial(material.id, "quantity", Number.parseFloat(e.target.value) || 0)
                          }
                          className="w-20"
                        />
                      </TableCell>
                      <TableCell>
                        <Select
                          value={material.unit}
                          onValueChange={(value) => updateMaterial(material.id, "unit", value)}
                        >
                          <SelectTrigger className="w-24">
                            <SelectValue placeholder="Unit" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="tons">Tons</SelectItem>
                            <SelectItem value="yards">Yards</SelectItem>
                            <SelectItem value="gallons">Gallons</SelectItem>
                            <SelectItem value="each">Each</SelectItem>
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <span className="mr-1">$</span>
                          <Input
                            type="number"
                            value={material.pricePerUnit}
                            onChange={(e) =>
                              updateMaterial(material.id, "pricePerUnit", Number.parseFloat(e.target.value) || 0)
                            }
                            className="w-20"
                          />
                        </div>
                      </TableCell>
                      <TableCell>${(material.quantity * material.pricePerUnit).toFixed(2)}</TableCell>
                      <TableCell>
                        <Button variant="ghost" size="icon" onClick={() => removeMaterial(material.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
              <Button variant="outline" size="sm" className="mt-4" onClick={addMaterial}>
                <Plus className="h-4 w-4 mr-2" /> Add Material
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Trucking</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Truck Type</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Tonnage per Truck</TableHead>
                    <TableHead>Cost per Truck</TableHead>
                    <TableHead>Total Tonnage</TableHead>
                    <TableHead>Total Cost</TableHead>
                    <TableHead></TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {trucking.map((truck) => (
                    <TableRow key={truck.id}>
                      <TableCell>
                        <Select value={truck.type} onValueChange={(value) => updateTrucking(truck.id, "type", value)}>
                          <SelectTrigger className="w-36">
                            <SelectValue placeholder="Select truck type" />
                          </SelectTrigger>
                          <SelectContent>
                            {Object.keys(truckingRates).map((type) => (
                              <SelectItem key={type} value={type}>
                                {type}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={truck.amount}
                          onChange={(e) => updateTrucking(truck.id, "amount", Number.parseFloat(e.target.value) || 0)}
                          className="w-20"
                        />
                      </TableCell>
                      <TableCell>
                        <Input
                          type="number"
                          value={truck.tonnage}
                          onChange={(e) => updateTrucking(truck.id, "tonnage", Number.parseFloat(e.target.value) || 0)}
                          className="w-20"
                        />
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center">
                          <span className="mr-1">$</span>
                          <Input
                            type="number"
                            value={truck.costPerTruck}
                            onChange={(e) =>
                              updateTrucking(truck.id, "costPerTruck", Number.parseFloat(e.target.value) || 0)
                            }
                            className="w-20"
                          />
                        </div>
                      </TableCell>
                      <TableCell>{truck.totalTonnage.toFixed(2)} tons</TableCell>
                      <TableCell>${truck.totalCost.toFixed(2)}</TableCell>
                      <TableCell>
                        <Button variant="ghost" size="icon" onClick={() => removeTrucking(truck.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                  <TableRow>
                    <TableCell colSpan={4} className="text-right font-bold">
                      Totals:
                    </TableCell>
                    <TableCell className="font-bold">{calculateTotalTruckingTonnage().toFixed(2)} tons</TableCell>
                    <TableCell className="font-bold">${calculateTotalTruckingCost().toFixed(2)}</TableCell>
                    <TableCell></TableCell>
                  </TableRow>
                </TableBody>
              </Table>
              <Button variant="outline" size="sm" className="mt-4" onClick={addTrucking}>
                <Plus className="h-4 w-4 mr-2" /> Add Trucking
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Job Cost Summary</CardTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                setShowItemizedSummary(!showItemizedSummary)
                saveToLocalStorage()
              }}
              className="flex items-center gap-1"
            >
              {showItemizedSummary ? (
                <>
                  Hide Details <ChevronUp className="h-4 w-4" />
                </>
              ) : (
                <>
                  Show Details <ChevronDown className="h-4 w-4" />
                </>
              )}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex justify-between py-2">
              <span>Equipment Cost (Selected Sections):</span>
              <span className="font-medium">${calculateTotalEquipmentCost().toFixed(2)}</span>
            </div>

            {showItemizedSummary && (
              <div className="pl-4 space-y-2 text-sm text-muted-foreground">
                {sections
                  .filter((section) => section.selected)
                  .map((section) => (
                    <div key={section.id} className="space-y-1">
                      <div className="font-medium">
                        {section.name} - ${calculateSectionCost(section).toFixed(2)}
                      </div>
                      <div className="pl-4">
                        {section.items.map((item) => (
                          <div key={item.id} className="italic">
                            {item.equipment}: {item.hours} hrs @ ${item.rate}/hr = $
                            {(item.hours * item.rate).toFixed(2)}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
              </div>
            )}

            <Separator />
            <div className="flex justify-between py-2">
              <span>Labor Cost (Selected Sections):</span>
              <span className="font-medium">${calculateTotalLaborCost().toFixed(2)}</span>
            </div>

            {showItemizedSummary && (
              <div className="pl-4 space-y-2 text-sm text-muted-foreground">
                {sections
                  .filter((section) => section.selected)
                  .map((section) => (
                    <div key={section.id} className="space-y-1">
                      <div className="font-medium">
                        {section.name} - ${calculateSectionLaborCost(section).toFixed(2)}
                      </div>
                      <div className="pl-4">
                        {section.labor.map((item) => (
                          <div key={item.id} className="italic">
                            {item.role}: {item.hours} hrs @ ${item.rate}/hr = ${(item.hours * item.rate).toFixed(2)}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
              </div>
            )}

            <Separator />
            <div className="flex justify-between py-2">
              <span>Materials Cost:</span>
              <span className="font-medium">${calculateTotalMaterialCost().toFixed(2)}</span>
            </div>

            {showItemizedSummary && (
              <div className="pl-4 space-y-1 text-sm text-muted-foreground">
                {materials.map((material) => (
                  <div key={material.id} className="italic">
                    {material.name}: {material.quantity} {material.unit} @ ${material.pricePerUnit}/{material.unit} = $
                    {(material.quantity * material.pricePerUnit).toFixed(2)}
                  </div>
                ))}
              </div>
            )}

            <Separator />
            <div className="flex justify-between py-2">
              <span>Trucking Cost:</span>
              <span className="font-medium">${calculateTotalTruckingCost().toFixed(2)}</span>
            </div>

            {showItemizedSummary && (
              <div className="pl-4 space-y-1 text-sm text-muted-foreground">
                {trucking.map((truck) => (
                  <div key={truck.id} className="italic">
                    {truck.type}: {truck.amount} trucks @ ${truck.costPerTruck}/truck = ${truck.totalCost.toFixed(2)} (
                    {truck.totalTonnage} tons)
                  </div>
                ))}
                <div className="font-medium mt-1">Total Tonnage: {calculateTotalTruckingTonnage().toFixed(2)} tons</div>
              </div>
            )}

            <Separator />
            <div className="flex justify-between py-2 text-lg font-bold">
              <span>Total Job Cost:</span>
              <span>${calculateTotalJobCost().toFixed(2)}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Configuration Dialog */}
      <Dialog open={configDialogOpen} onOpenChange={setConfigDialogOpen}>
        <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Configuration</DialogTitle>
            <DialogDescription>
              Configure equipment rates, trucking rates, company information, and other settings.
            </DialogDescription>
          </DialogHeader>

          <Tabs defaultValue="equipment">
            <TabsList className="grid grid-cols-3 mb-4">
              <TabsTrigger value="equipment">Equipment Rates</TabsTrigger>
              <TabsTrigger value="trucking">Trucking Rates</TabsTrigger>
              <TabsTrigger value="company">Company Info</TabsTrigger>
            </TabsList>

            <TabsContent value="equipment" className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-medium">Equipment Rates</h3>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      const name = prompt("Enter new equipment name:")
                      const rate = prompt("Enter hourly rate:")
                      if (name) addEquipmentType(name, rate)
                    }}
                  >
                    Add Equipment Type
                  </Button>
                </div>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Equipment</TableHead>
                      <TableHead>Rate</TableHead>
                      <TableHead></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {Object.entries(equipmentRates).map(([equipment, rate]) => (
                      <TableRow key={equipment}>
                        <TableCell>{equipment}</TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <span className="mr-1">$</span>
                            <Input
                              type="number"
                              value={rate}
                              onChange={(e) => updateEquipmentRate(equipment, e.target.value)}
                              className="w-24"
                            />
                          </div>
                        </TableCell>
                        <TableCell>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => {
                              removeEquipmentType(equipment)
                              saveToLocalStorage()
                            }}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            <TabsContent value="trucking" className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-medium">Trucking Rates</h3>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      const type = prompt("Enter new truck type:")
                      const tonnage = prompt("Enter tonnage per truck:")
                      const costPerTruck = prompt("Enter cost per truck:")
                      if (type) addTruckingType(type, tonnage, costPerTruck)
                    }}
                  >
                    Add Truck Type
                  </Button>
                </div>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Truck Type</TableHead>
                      <TableHead>Tonnage per Truck</TableHead>
                      <TableHead>Cost per Truck</TableHead>
                      <TableHead></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {Object.entries(truckingRates).map(([type, data]) => (
                      <TableRow key={type}>
                        <TableCell>{type}</TableCell>
                        <TableCell>
                          <Input
                            type="number"
                            value={data.tonnage}
                            onChange={(e) => updateTruckingRate(type, "tonnage", e.target.value)}
                            className="w-24"
                          />
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center">
                            <span className="mr-1">$</span>
                            <Input
                              type="number"
                              value={data.costPerTruck}
                              onChange={(e) => updateTruckingRate(type, "costPerTruck", e.target.value)}
                              className="w-24"
                            />
                          </div>
                        </TableCell>
                        <TableCell>
                          <Button variant="ghost" size="icon" onClick={() => removeTruckingType(type)}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            <TabsContent value="company" className="space-y-4">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Company Information</h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="companyName">Company Name</Label>
                    <Input
                      id="companyName"
                      value={companyInfo.name}
                      onChange={(e) => updateCompanyInfo("name", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="companyAddress">Address</Label>
                    <Input
                      id="companyAddress"
                      value={companyInfo.address}
                      onChange={(e) => updateCompanyInfo("address", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="companyCity">City</Label>
                    <Input
                      id="companyCity"
                      value={companyInfo.city}
                      onChange={(e) => updateCompanyInfo("city", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="companyState">State</Label>
                    <Input
                      id="companyState"
                      value={companyInfo.state}
                      onChange={(e) => updateCompanyInfo("state", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="companyZip">ZIP Code</Label>
                    <Input
                      id="companyZip"
                      value={companyInfo.zip}
                      onChange={(e) => updateCompanyInfo("zip", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="companyPhone">Phone</Label>
                    <Input
                      id="companyPhone"
                      value={companyInfo.phone}
                      onChange={(e) => updateCompanyInfo("phone", e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="companyEmail">Email</Label>
                    <Input
                      id="companyEmail"
                      value={companyInfo.email}
                      onChange={(e) => updateCompanyInfo("email", e.target.value)}
                    />
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>

          <DialogFooter>
            <Button variant="outline" onClick={() => setConfigDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => {
                saveToLocalStorage()
                setConfigDialogOpen(false)
              }}
            >
              Save Configuration
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <JobSummary
        jobName={jobName}
        jobLocation={jobLocation}
        jobDate={jobDate}
        jobNotes={jobNotes}
        companyInfo={companyInfo}
        sections={sections}
        materials={materials}
        trucking={trucking}
        calculateSectionCost={calculateSectionCost}
        calculateSectionLaborCost={calculateSectionLaborCost}
        calculateTotalEquipmentCost={calculateTotalEquipmentCost}
        calculateTotalLaborCost={calculateTotalLaborCost}
        calculateTotalMaterialCost={calculateTotalMaterialCost}
        calculateTotalTruckingCost={calculateTotalTruckingCost}
        calculateTotalTruckingTonnage={calculateTotalTruckingTonnage}
        calculateTotalJobCost={calculateTotalJobCost}
        open={jobSummaryOpen}
        onClose={() => setJobSummaryOpen(false)}
      />
    </div>
  )
}

